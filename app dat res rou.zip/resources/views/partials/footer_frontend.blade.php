<div class="bg-dark text-secondary px-4 py-1 text-center">
    <div class="py-1">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
        <div class="col-md-4 d-flex align-items-center">
            <img src="/favicons/android-chrome-192x192.png" style="width:30px;margin-right:10px">
            <span class="text-muted" style="font-size:19px">© 2022 Plutus Builder</span>
        </div>
    
        <ul class="nav col-md-4 justify-content-end list-unstyled d-flex" style="font-size:25px">
            <li class="ms-3"><a class="text-muted" href="#"><i class="fa-brands fa-facebook"></i></a></li>
            <li class="ms-3"><a class="text-muted" href="#"><i class="fa-brands fa-instagram"></i></a></li>
            <li class="ms-3"><a class="text-muted" href="#"><i class="fa-brands fa-linkedin"></i></a></li>
        </ul>
        </footer>
    </div>
</div>
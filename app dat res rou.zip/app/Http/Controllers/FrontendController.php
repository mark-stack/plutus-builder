<?php

namespace App\Http\Controllers;

class FrontendController extends Controller {

    public function landing(){

        return view('frontend.landing');
    }

}
